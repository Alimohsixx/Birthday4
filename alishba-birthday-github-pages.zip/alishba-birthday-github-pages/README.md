# Alishba Zainab Birthday Surprise

## Publish with GitHub Pages

1. Create a new GitHub repository, for example `alishba-birthday`.
2. Upload `index.html` from this folder to the repository's top level (not inside another folder).
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch **main** and folder **/(root)**, then click **Save**.
6. After GitHub Pages finishes deploying, use the site URL shown on the Pages settings screen.

The page is a static HTML site. It loads Tailwind CSS and Google Fonts from their CDNs, so visitors need an internet connection for those external resources.

**Privacy note:** The page currently displays a person's full name and date of birth. GitHub Pages websites are public on the internet; review or remove any personal details before publishing.
